# 🚀 Guide d'Installation - ProjetFoncier

## Installation Rapide

### 1. Extraction
```bash
# Extraire le fichier ZIP dans le dossier de votre choix
unzip ProjetFoncier_DVF_Analysis_*.zip
cd ProjetFoncier_DVF_Analysis_*
```

### 2. Environnement Python
```bash
# Créer un environnement virtuel
python -m venv venv

# Activer l'environnement
# Windows:
venv\Scripts\activate
# Linux/Mac:
source venv/bin/activate
```

### 3. Installation des dépendances
```bash
# Installer toutes les dépendances
pip install -r requirements.txt
```

### 4. Validation
```bash
# Test rapide (30 secondes)
python rapid_validation.py

# Validation complète (optionnel, 10-15 minutes)
python validate_notebooks.py
```

### 5. Lancement
```bash
# Démarrer Jupyter
jupyter lab
# ou
jupyter notebook
```

## Démarrage Recommandé

1. **Navigation rapide**: Commencer par `03_visualizations.ipynb`
2. **Recommandations**: Consulter `04_recommendations.ipynb`
3. **Analyse détaillée**: Explorer `02_analysis.ipynb`
4. **Compréhension**: Étudier `01_preprocessing.ipynb`

## Résultats Inclus

✅ **26,914 transactions analysées** (départements 91 & 94)
✅ **Rendement moyen : 5.6%** brut par an
✅ **Zone prioritaire : Département 91** (6.2% rendement)
✅ **3 profils d'investisseurs** avec recommandations personnalisées

## Support

- 📖 README.md : Documentation complète
- 🎯 outputs/recommendations/ : Rapports d'investissement
- 📊 outputs/reports/ : Analyses techniques
- 📈 outputs/visualizations/ : Graphiques et cartes

## Problèmes Fréquents

### Widgets non affichés
```bash
pip install --upgrade ipywidgets
jupyter nbextension enable --py widgetsnbextension
```

### Erreur de mémoire
```bash
# Réduire sample_size dans les notebooks
# Variables configurables disponibles
```

### Encoding des données
```bash
# Le script gère automatiquement les encodings
# Pas d'action requise
```

---

**Version**: 1.0.0
**Date**: 16/09/2025
**Contact**: Voir README.md pour plus d'informations
